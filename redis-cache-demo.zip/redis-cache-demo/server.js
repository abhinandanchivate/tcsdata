const express = require("express");
const redis = require("redis");
const axios = require("axios");

const app = express();

const redisClient = redis.createClient(6379);

const checkCache = (req, res, next) => {
  redisClient.get("users", (err, data) => {
    if (!err) {
      if (data) {
        console.log("response from redis");
        res.json(JSON.parse(data));
      } else {
        next();
      }
    }
  });
};
app.get("/", checkCache, (req, res) => {
  axios.get("http://jsonplaceholder.typicode.com/users").then((response) => {
    redisClient.setex("users", 3600, JSON.stringify(response.data));
    res.json(response.data);
  });
});

app.listen(3000, () => {
  console.log("server started");
});
