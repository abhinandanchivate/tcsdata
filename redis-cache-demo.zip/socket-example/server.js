const http = require("http");
const express = require("express");
const socketIO = require("socket.io");

const app = express();

app.use(express.static("public"));
const server = http.createServer(app);

const io = socketIO(server);
io.on("connection", (socket) => {
  console.log("some one connected");
  socket.on("onMsgFromClient", (msg) => {
    io.emit("onMsgFromServer", msg);
  });
});

server.listen(3000, () => {
  console.log("server started");
});
