const express = require("express");

const app = express();

const users = [
  { id: 1, name: "john" },
  { id: 2, name: "Doe" },
  { id: 3, name: "Chris" },
  { id: 4, name: "jane" },
];

app.get("/users", (req, res) => {
  res.json(users);
});

app.get("/users/:id", (req, res) => {
  const { id } = req.params;

  res.json(users[id]);
});

module.exports = app;
