const add = (a, b) => a + b;
const divide = (a, b) => {
  if (b === 0) throw new Error("Divide By Zero Error");
  // if (b === 0) return ('Divide By Zero Error')
  // === : it is used to check type and value
  // == will check value
  // 10==='10' ===> false
  // 10=='10' ===> true
  return a / b;
};

const mul = (a, b) => a * b;
const sub = (a, b) => a - b;

module.exports = { add, divide, sub, mul };
