const chai = require("chai");

const chaiHttp = require("chai-http");

const app = require("../app");

const expect = chai.expect;

chai.use(chaiHttp);

describe("Rest Api", () => {
  it("should return 200 for /users", () => {
    chai
      .request(app)
      .get("/users/2")
      .end((err, res) => {
        console.log(JSON.stringify(res));
        expect(res.status).to.be.equal(200);
        expect(err).to.be.equal(null);
        expect(res.body.id).to.be.greaterThan(5);
      });
  });
});
