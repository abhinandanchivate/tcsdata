const chai = require("chai");
const { add, divide } = require("../sample");

const expect = chai.expect;

describe("Arithmetic Operations", () => {
  it("should add two number", () => {
    expect(add(10, 20)).to.equal(30);
  });
});
